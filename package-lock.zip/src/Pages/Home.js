import React from 'react'
import Form from '../Comps/Form'

export default function Home() {
  return (
    <div className='bg-dark d-flex justify-content-center align-items-center' style={{height:"100vh"}} >

        <Form/>

    </div>
  )
}
