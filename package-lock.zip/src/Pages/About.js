import React from 'react'
import Table from '../Comps/Table'

export default function About() {
  return (
    <div className='bg-dark py-2' style={{height:"100vh"}} >
      <Table/>
    </div>
  )
}
